# PulseCare — Medical Demo Landing Page

A standalone healthcare landing-page demo for a fictional family clinic concept.

## Preview locally
Open `index.html` in a modern browser.

## Deploy with GitHub Pages
1. Upload `index.html` to the root of the `main` branch in `Ruqayya44/Medical-Demo-Landing-Page`.
2. In repository Settings → Pages, choose **Deploy from a branch**.
3. Select branch `main` and folder `/ (root)`, then Save.

> Demo concept only. Not a live clinic website. Contact details and appointment availability shown in the demo are placeholders.
